export const sweetsCategory = ['SugarFree', 'BengaliSweets', 'Sweets'];
export const decorationCategory = ['Marriage', "BirthDay", "Mehndi", "Party", "RoomDecor"]
export const designerCategory = ['Bridge', 'Groom', 'Suits', 'Other'];
// export const invitationCategory = ['invitation', 'invitation_wooden_box', 'invitation_box', 'invitation_glass_box', 'misc_invitation',]
export const filterData = ['50-150', '150-300', '300-500', '500 & Above', 'All']
export const planningCategory = [{ name: 'Marriage', url: '/planning-tool' }, { name: "Birthday", url: '/planning-birthday' }, { name: "Mehndi", url: '/planning-mehndi' }, { name: "Party", url: '/planning-party' }, { name: "Room Decor", url: '/planning-other' }]
export const invitationCategory = ['Invitation', 'Wooden Box', 'Invitation On Box', 'Glass Box', 'Misc Invitation']
export const sweetFilterData = ['200-300', '300-500', '500-700', '700 & Above', 'All']
