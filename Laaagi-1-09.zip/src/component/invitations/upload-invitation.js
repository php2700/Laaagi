export const UploadInvitation = () => {
    return (
        <div>thi sdcszcs</div>
    )
}