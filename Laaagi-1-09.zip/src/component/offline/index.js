import './index.css'

export const Offline = () => {
    return (
        <div className="bannerStyle">
            🔌 You are offline. Please check your internet connection.
        </div>
    )
}